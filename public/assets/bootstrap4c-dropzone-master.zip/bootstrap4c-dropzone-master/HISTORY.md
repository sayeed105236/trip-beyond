# Release History

## 1.0.6

* Added `is-valid` and `is-invalid` styles

## 1.0.5

* Upgraded to Bootstrap 4.3.1

## 1.0.4

* Upgraded to Bootstrap 4.1.0

## 1.0.3

* Upgraded to Bootstrap 4.0.0

## 1.0.2

* Fixed height issue (#1)
* SASS SVG URI

## 1.0.1

* Build issue fixed

## 1.0.0

* First release
